package project5;

/**
 * Stores information regarding a song's
 * like and heard stats based on hobby
 * 
 * @author Truman Heberle trumanh
 * @version 4.15.2017
 */
public class HobbyTracker {
    private int readHeard;
    private int readLiked;
    private int artHeard;
    private int artLiked;
    private int sportsHeard;
    private int sportsLiked;
    private int musicHeard;
    private int musicLiked;
    
    public HobbyTracker() {
        
    }
}
