package project5;

/**
 * Contains all the types of Regions
 * @author Truman Heberle trumanh
 * @version 4.15.2017
 */
public enum RegionEnum {
    NORTH_EAST_US,
    SOUTH_EAST_US,
    OTHER_US,
    OUTSIDE_US;
}
