package project5;

/**
 * Contains all types of Hobbies
 * @author Truman Heberle trumanh
 * @version 4.15.2017
 */
public enum HobbyEnum {
    READ,
    ART,
    SPORTS,
    MUSIC;
}
