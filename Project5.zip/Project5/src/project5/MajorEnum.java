package project5;

/**
 * Contains all types of Majors
 * @author Truman Heberle trumanh
 * @version 4.15.2017
 */
public enum MajorEnum {
    COMPUTER_SCIENCE,
    OTHER_ENGINEERING,
    MATH_CMDA,
    OTHER;
}
